#!/usr/bin/env python
"""
LINK EXISTING VOLUNTEERS, DONORS, CLIENTS TO USER ACCOUNTS
Run this after populating data to create login accounts
"""

import os
import django
from django.contrib.auth.hashers import make_password

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'community_harvest.settings')
django.setup()

from base.models import (
    User, VolunteerProfile, DonorProfile, ClientProfile,
    Volunteer, Donor, Clientfamily, Contactperson
)

def link_data():
    print("=" * 60)
    print("LINKING EXISTING DATA TO USER ACCOUNTS")
    print("=" * 60)

    # ============================================
    # 1. LINK VOLUNTEERS
    # ============================================
    print("\n1. Linking Volunteers to User accounts...")
    volunteer_count = 0
    for volunteer in Volunteer.objects.all():
        if volunteer.email:
            # Create username from email
            username = volunteer.email.split('@')[0]
            
            # Make sure username is unique
            if User.objects.filter(username=username).exists():
                username = f"{username}_{volunteer.volid}"
            
            # Create User account
            user, created = User.objects.get_or_create(
                username=username,
                defaults={
                    'email': volunteer.email,
                    'first_name': volunteer.firstname,
                    'last_name': volunteer.lastname,
                    'user_type': 'volunteer',
                    'password': make_password('volunteer123')  # Default password
                }
            )
            
            # Create Profile link
            VolunteerProfile.objects.get_or_create(
                user=user,
                defaults={'existing_volunteer': volunteer}
            )
            
            if created:
                volunteer_count += 1
                print(f"  ✓ Linked: {volunteer.firstname} {volunteer.lastname} (Username: {user.username})")
            else:
                print(f"  ⚠ Already linked: {volunteer.firstname}")
    
    print(f"  Total volunteers linked: {volunteer_count}")

    # ============================================
    # 2. LINK DONORS
    # ============================================
    print("\n2. Linking Donors to User accounts...")
    donor_count = 0
    for donor in Donor.objects.all():
        # Find a contact person with email
        contact = Contactperson.objects.filter(donorid=donor).first()
        
        if contact and contact.email:
            username = contact.email.split('@')[0]
            
            if User.objects.filter(username=username).exists():
                username = f"donor_{donor.donorid}"
            
            user, created = User.objects.get_or_create(
                username=username,
                defaults={
                    'email': contact.email,
                    'first_name': donor.donorname,
                    'last_name': '',
                    'user_type': 'donor',
                    'password': make_password('donor123')
                }
            )
            
            DonorProfile.objects.get_or_create(
                user=user,
                defaults={'existing_donor': donor}
            )
            
            if created:
                donor_count += 1
                print(f"  ✓ Linked: {donor.donorname} (Username: {user.username})")
        else:
            # Create without email
            username = f"donor_{donor.donorid}"
            user, created = User.objects.get_or_create(
                username=username,
                defaults={
                    'email': f"{username}@donor.local",
                    'first_name': donor.donorname,
                    'user_type': 'donor',
                    'password': make_password('donor123')
                }
            )
            
            DonorProfile.objects.get_or_create(
                user=user,
                defaults={'existing_donor': donor}
            )
            
            if created:
                donor_count += 1
                print(f"  ✓ Linked: {donor.donorname} (Username: {user.username})")
    
    print(f"  Total donors linked: {donor_count}")

    # ============================================
    # 3. LINK CLIENTS
    # ============================================
    print("\n3. Linking Clients to User accounts...")
    client_count = 0
    for client in Clientfamily.objects.all():
        username = client.familyname.lower().replace(' ', '_')
        
        if User.objects.filter(username=username).exists():
            username = f"client_{client.familyid}"
        
        user, created = User.objects.get_or_create(
            username=username,
            defaults={
                'email': f"{client.familyid}@client.local",
                'first_name': client.familyname,
                'last_name': 'Family',
                'user_type': 'client',
                'password': make_password('client123')
            }
        )
        
        ClientProfile.objects.get_or_create(
            user=user,
            defaults={'existing_client': client}
        )
        
        if created:
            client_count += 1
            print(f"  ✓ Linked: {client.familyname} (Username: {user.username})")
    
    print(f"  Total clients linked: {client_count}")

    # ============================================
    # SUMMARY
    # ============================================
    print("\n" + "=" * 60)
    print("✅ LINKING COMPLETE!")
    print("=" * 60)
    print(f"\n📊 SUMMARY:")
    print(f"   • Users created: {User.objects.count()}")
    print(f"   • Volunteer Profiles: {VolunteerProfile.objects.count()}")
    print(f"   • Donor Profiles: {DonorProfile.objects.count()}")
    print(f"   • Client Profiles: {ClientProfile.objects.count()}")
    
    print("\n🔑 LOGIN CREDENTIALS:")
    print("   Volunteers: Username = email prefix, Password = volunteer123")
    print("   Donors: Username = donor_[ID], Password = donor123")
    print("   Clients: Username = client_[ID], Password = client123")
    print("=" * 60)

if __name__ == "__main__":
    response = input("\n⚠️  This will create User accounts for all existing volunteers, donors, and clients. Continue? (yes/no): ")
    if response.lower() == 'yes':
        link_data()
    else:
        print("Operation cancelled.")