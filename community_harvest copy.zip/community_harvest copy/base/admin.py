from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import (
    User, VolunteerProfile, DonorProfile, ClientProfile,
    Volunteer, Donor, Clientfamily, Contactperson
)

# ============================================
# CUSTOM USER ADMIN
# ============================================

@admin.register(User)
class CustomUserAdmin(UserAdmin):
    list_display = ['username', 'email', 'first_name', 'last_name', 'user_type', 'get_role', 'is_active', 'is_staff']
    list_filter = ['user_type', 'is_active', 'is_staff']
    search_fields = ['username', 'email', 'first_name', 'last_name']
    
    fieldsets = UserAdmin.fieldsets + (
        ('User Type', {'fields': ('user_type',)}),
    )
    
    def get_role(self, obj):
        """Get the specific role based on user type"""
        if obj.user_type == 'volunteer':
            try:
                profile = VolunteerProfile.objects.get(user=obj)
                if profile.existing_volunteer:
                    return profile.existing_volunteer.role
            except:
                return 'No role'
        elif obj.user_type == 'donor':
            try:
                profile = DonorProfile.objects.get(user=obj)
                if profile.existing_donor:
                    return profile.existing_donor.donortype
            except:
                return 'No type'
        elif obj.user_type == 'client':
            return 'Family'
        return '-'
    get_role.short_description = 'Role/Type'

# ============================================
# VOLUNTEER ADMIN
# ============================================

@admin.register(Volunteer)
class VolunteerAdmin(admin.ModelAdmin):
    list_display = ['volid', 'firstname', 'lastname', 'email', 'role', 'get_linked_username']
    list_filter = ['role']
    search_fields = ['firstname', 'lastname', 'email']
    
    def get_linked_username(self, obj):
        try:
            profile = VolunteerProfile.objects.get(existing_volunteer=obj)
            return profile.user.username
        except:
            return 'No user linked'
    get_linked_username.short_description = 'Username'

# ============================================
# DONOR ADMIN
# ============================================

@admin.register(Donor)
class DonorAdmin(admin.ModelAdmin):
    list_display = ['donorid', 'donorname', 'donortype', 'get_linked_username']
    list_filter = ['donortype']
    search_fields = ['donorname']
    
    def get_linked_username(self, obj):
        try:
            profile = DonorProfile.objects.get(existing_donor=obj)
            return profile.user.username
        except:
            return 'No user linked'
    get_linked_username.short_description = 'Username'

# ============================================
# CLIENT ADMIN
# ============================================

@admin.register(Clientfamily)
class ClientAdmin(admin.ModelAdmin):
    list_display = ['familyid', 'familyname', 'phone', 'familysize', 'get_linked_username']
    search_fields = ['familyname', 'address', 'phone']
    
    def get_linked_username(self, obj):
        try:
            profile = ClientProfile.objects.get(existing_client=obj)
            return profile.user.username
        except:
            return 'No user linked'
    get_linked_username.short_description = 'Username'

# ============================================
# PROFILE ADMINS
# ============================================

@admin.register(VolunteerProfile)
class VolunteerProfileAdmin(admin.ModelAdmin):
    list_display = ['id', 'get_username', 'get_volunteer_name', 'get_role']
    search_fields = ['user__username', 'existing_volunteer__firstname']
    
    def get_username(self, obj):
        return obj.user.username
    get_username.short_description = 'Username'
    
    def get_volunteer_name(self, obj):
        if obj.existing_volunteer:
            return f"{obj.existing_volunteer.firstname} {obj.existing_volunteer.lastname}"
        return 'No volunteer'
    get_volunteer_name.short_description = 'Volunteer Name'
    
    def get_role(self, obj):
        if obj.existing_volunteer:
            return obj.existing_volunteer.role
        return '-'
    get_role.short_description = 'Role'

@admin.register(DonorProfile)
class DonorProfileAdmin(admin.ModelAdmin):
    list_display = ['id', 'get_username', 'get_donor_name', 'get_donor_type']
    search_fields = ['user__username', 'existing_donor__donorname']
    
    def get_username(self, obj):
        return obj.user.username
    get_username.short_description = 'Username'
    
    def get_donor_name(self, obj):
        if obj.existing_donor:
            return obj.existing_donor.donorname
        return 'No donor'
    get_donor_name.short_description = 'Donor Name'
    
    def get_donor_type(self, obj):
        if obj.existing_donor:
            return obj.existing_donor.donortype
        return '-'
    get_donor_type.short_description = 'Donor Type'

@admin.register(ClientProfile)
class ClientProfileAdmin(admin.ModelAdmin):
    list_display = ['id', 'get_username', 'get_client_name']
    search_fields = ['user__username', 'existing_client__familyname']
    
    def get_username(self, obj):
        return obj.user.username
    get_username.short_description = 'Username'
    
    def get_client_name(self, obj):
        if obj.existing_client:
            return obj.existing_client.familyname
        return 'No client'
    get_client_name.short_description = 'Client Name'

# ============================================
# CONTACT PERSON ADMIN
# ============================================

@admin.register(Contactperson)
class ContactPersonAdmin(admin.ModelAdmin):
    list_display = ['contactid', 'name', 'phone', 'email', 'donorid']
    search_fields = ['name', 'email']