from django.urls import path
from . import views
from django.contrib.auth.views import LogoutView


urlpatterns = [
    path('', views.HomePageView.as_view(), name='home'),
    path('about/', views.AboutPageView.as_view(), name='about'),
    path('signup/', views.SignupChoiceView.as_view(), name='signup_choice'),
    path('signup/volunteer/', views.VolunteerRegisterView.as_view(), name='volunteer_signup'),
    path('signup/donor/', views.DonorRegisterView.as_view(), name='donor_signup'),
    path('signup/client/', views.ClientRegisterView.as_view(), name='client_signup'),
    path('donor/contacts/', views.DonorContactsView.as_view(), name='donor_contacts'),
    path('login/', views.CustomLoginView.as_view(), name='login'),
    path('logout/', LogoutView.as_view(next_page='home'), name='logout'),
    path('forgot-password/', views.ForgotPasswordView.as_view(), name='forgot_password'),
    path('reset-password/', views.ResetPasswordView.as_view(), name='reset_password'),
    path('volunteer/dashboard/', views.VolunteerDashboardView.as_view(), name='volunteer_dashboard'),
    path('donor/dashboard/', views.DonorDashboardView.as_view(), name='donor_dashboard'),
    path('client/dashboard/', views.ClientDashboardView.as_view(), name='client_dashboard'),
    path('donor/make-donation/', views.MakeDonationView.as_view(), name='make_donation'),
    # Add to urls.py

# Donation CRUD
path('donation/<int:pk>/update/', views.DonationUpdateView.as_view(), name='donation_update'),
path('donation/<int:pk>/delete/', views.DonationDeleteView.as_view(), name='donation_delete'),

# Quality Checks
path('quality-checks/', views.QualityCheckListView.as_view(), name='quality_check_list'),
path('quality-check/<int:pk>/update/', views.QualityCheckUpdateView.as_view(), name='quality_check_update'),

# Distribution
path('distribution/create/', views.DistributionCreateView.as_view(), name='distribution_create'),

# Items
path('item/create/', views.ItemCreateView.as_view(), name='item_create'),

# urls.py
path('package/create/', views.PackageCreateView.as_view(), name='package_create'),
path('packages/', views.PackageListView.as_view(), name='package_list'),
path('distributions/', views.DistributionListView.as_view(), name='distribution_list'),
path('distribution/update-status/<int:pk>/', views.UpdateDeliveryStatusView.as_view(), name='update_delivery_status'),

# Add these to your urlpatterns
path('reports/expiring-items/', views.ExpiringItemsReportView.as_view(), name='expiring_items_report'),
path('reports/donor-family/', views.DonorToFamilyReportView.as_view(), name='donor_family_report'),
    
]
