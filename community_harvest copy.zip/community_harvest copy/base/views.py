from django.shortcuts import render, redirect, get_object_or_404
from django.shortcuts import render, redirect
from django.views import View
from django.views.generic import TemplateView, CreateView
from django.contrib.auth.views import LoginView
from django.contrib.auth.models import User
from django.contrib import messages
from django.urls import reverse_lazy
from django.db import models
from datetime import date, timedelta
import random



from .models import (
    User, VolunteerProfile, DonorProfile, ClientProfile,
    Volunteer, Donor, Clientfamily, Contactperson,
    Donationevent, Qualitychecklog, Inventoryassignment,
    Donationlineitem, Donationwarehouse, Warehouse, Zone,
    Items, Foodpackage, Foodpackageitems, Distributionevent,
    Volunteerzone, Evaluationhistory, Inspector, Perishable, Nonperishable, DeliveryStatus
)
from .forms import (
    VolunteerRegistrationForm, DonorRegistrationForm, ClientRegistrationForm,
    ContactPersonForm
)

# ============================================
# STATIC PAGES
# ============================================

class HomePageView(TemplateView):
    template_name = 'base/home.html'

class AboutPageView(TemplateView):
    template_name = 'base/about.html'

class SignupChoiceView(TemplateView):
    template_name = 'base/signup_choice.html'

# ============================================
# REGISTRATION VIEWS
# ============================================

class VolunteerRegisterView(CreateView):
    form_class = VolunteerRegistrationForm
    template_name = 'base/volunteer_signup.html'
    success_url = reverse_lazy('login')
    
    def form_valid(self, form):
        response = super().form_valid(form)
        messages.success(self.request, 'Volunteer account created! Please login.')
        return response

class DonorRegisterView(CreateView):
    form_class = DonorRegistrationForm
    template_name = 'base/donor_signup.html'
    success_url = reverse_lazy('login')
    
    def form_valid(self, form):
        response = super().form_valid(form)
        messages.success(self.request, 'Donor account created! Please login.')
        return response

class ClientRegisterView(CreateView):
    form_class = ClientRegistrationForm
    template_name = 'base/client_signup.html'
    success_url = reverse_lazy('login')
    
    def form_valid(self, form):
        response = super().form_valid(form)
        messages.success(self.request, 'Client account created! Please login.')
        return response

# ============================================
# DONOR CONTACTS (After signup)
# ============================================

class DonorContactsView(View):
    template_name = 'base/donor_contacts.html'
    
    def get(self, request):
        if not request.user.is_authenticated or request.user.user_type != 'donor':
            return redirect('login')
        
        try:
            donor_profile = DonorProfile.objects.get(user=request.user)
            donor = donor_profile.existing_donor
        except DonorProfile.DoesNotExist:
            messages.error(request, 'Donor profile not found')
            return redirect('login')
        
        donor_type = donor.donortype
        max_contacts = 3 if donor_type == 'Organization' else 2
        current_count = Contactperson.objects.filter(donorid=donor).count()
        
        if current_count >= max_contacts:
            return redirect('donor_dashboard')
        
        return render(request, self.template_name, {
            'form': ContactPersonForm(),
            'contacts': Contactperson.objects.filter(donorid=donor),
            'max_contacts': max_contacts,
            'current_count': current_count,
            'donor_type': donor_type
        })
    
    def post(self, request):
        if not request.user.is_authenticated or request.user.user_type != 'donor':
            return redirect('login')
        
        donor_profile = DonorProfile.objects.get(user=request.user)
        donor = donor_profile.existing_donor
        
        form = ContactPersonForm(request.POST)
        if form.is_valid():
            contact = form.save(commit=False)
            contact.donorid = donor
            contact.save()
            messages.success(request, f'Contact {contact.name} added!')
        return redirect('donor_contacts')

# ============================================
# LOGIN & LOGOUT
# ============================================

class CustomLoginView(LoginView):
    template_name = 'base/login.html'
    redirect_authenticated_user = True
    
    def form_valid(self, form):
        response = super().form_valid(form)
        user = form.get_user()
        
        # FORCE set session
        self.request.session['user_type'] = user.user_type
        self.request.session.save()
        
        print(f"DEBUG: User {user.username} logged in with type {user.user_type}")  # Check terminal
        
        return response
    
    def get_success_url(self):
        user = self.request.user
        print(f"DEBUG: Redirecting user type: {user.user_type}")  # Check terminal
        
        if user.user_type == 'volunteer':
            return reverse_lazy('volunteer_dashboard')
        elif user.user_type == 'donor':
            return reverse_lazy('donor_dashboard')
        elif user.user_type == 'client':
            return reverse_lazy('client_dashboard')
        return reverse_lazy('home')

# ============================================
# VOLUNTEER DASHBOARD
# ============================================

class VolunteerDashboardView(View):
    template_name = 'base/volunteer_dashboard.html'
    
    def get(self, request):
        if not request.user.is_authenticated or request.user.user_type != 'volunteer':
            return redirect('login')
        
        try:
            profile = VolunteerProfile.objects.get(user=request.user)
            volunteer = profile.existing_volunteer
        except VolunteerProfile.DoesNotExist:
            messages.error(request, 'Volunteer profile not found')
            return redirect('login')
        
        assigned_zones = Volunteerzone.objects.filter(volid=volunteer).select_related('zoneid', 'zoneid__warehouseid')
        upcoming = Distributionevent.objects.filter(volid=volunteer, distributiondate__gte=date.today()).select_related('packageid', 'familyid')
        completed = Distributionevent.objects.filter(volid=volunteer, distributiondate__lt=date.today()).count()
        
        context = {
            'volunteer': volunteer,
            'is_squad_leader': volunteer.role == 'Squad Leader',
            'assigned_zones': assigned_zones,
            'upcoming_deliveries': upcoming,
            'upcoming_count': upcoming.count(),
            'completed_deliveries': completed,
        }
        return render(request, self.template_name, context)

# ============================================
# DONOR DASHBOARD
# ============================================

class DonorDashboardView(View):
    template_name = 'base/donor_dashboard.html'
    
    def get(self, request):
        if not request.user.is_authenticated or request.user.user_type != 'donor':
            return redirect('login')
        
        try:
            profile = DonorProfile.objects.get(user=request.user)
            donor = profile.existing_donor
        except DonorProfile.DoesNotExist:
            messages.error(request, 'Donor profile not found')
            return redirect('login')
        
        donations = Donationevent.objects.filter(donorid=donor).order_by('-donationdate')
        total_weight = donations.aggregate(total=models.Sum('totalweight'))['total'] or 0
        
        passed = failed = 0
        for d in donations:
            qc = Qualitychecklog.objects.filter(donationid=d).first()
            if qc:
                if qc.status == 'Pass':
                    passed += 1
                elif qc.status == 'Fail':
                    failed += 1
        
        context = {
            'donor': donor,
            'contacts': Contactperson.objects.filter(donorid=donor),
            'donations': donations,
            'total_weight': total_weight,
            'donation_count': donations.count(),
            'passed_checks': passed,
            'failed_checks': failed,
        }
        return render(request, self.template_name, context)

# ============================================
# CLIENT DASHBOARD
# ============================================

class ClientDashboardView(View):
    template_name = 'base/client_dashboard.html'
    
    def get(self, request):
        if not request.user.is_authenticated or request.user.user_type != 'client':
            return redirect('login')
        
        try:
            profile = ClientProfile.objects.get(user=request.user)
            client = profile.existing_client
        except ClientProfile.DoesNotExist:
            messages.error(request, 'Client profile not found')
            return redirect('login')
        
        distributions = Distributionevent.objects.filter(familyid=client).order_by('-distributiondate').select_related('packageid', 'volid')
        
        context = {
            'client': client,
            'distributions': distributions,
            'upcoming': distributions.filter(distributiondate__gte=date.today()),
            'past': distributions.filter(distributiondate__lt=date.today()),
            'total_packages': distributions.count(),
        }
        return render(request, self.template_name, context)

# ============================================
# DONATION ACTIONS
# ============================================

class MakeDonationView(View):
    template_name = 'base/make_donation.html'
    
    def get(self, request):
        if not request.user.is_authenticated or request.user.user_type != 'donor':
            return redirect('login')
        
        profile = DonorProfile.objects.get(user=request.user)
        donor = profile.existing_donor
        
        return render(request, self.template_name, {'donor': donor})
    
    def post(self, request):
        if not request.user.is_authenticated or request.user.user_type != 'donor':
            return redirect('login')
        
        profile = DonorProfile.objects.get(user=request.user)
        donor = profile.existing_donor
        
        quantity = int(request.POST.get('quantity', 1))
        
        # Create the donation
        donation = Donationevent.objects.create(
            donationdate=request.POST.get('donationdate'),
            totalweight=request.POST.get('totalweight'),
            donorid=donor
        )
        
        # Create or get the item
        item_name = request.POST.get('itemname')
        item_type = request.POST.get('itemtype')
        
        # Check if item already exists
        item, created = Items.objects.get_or_create(
            itemname=item_name,
            defaults={
                'sku': random.randint(10000, 99999),
                'category': item_type
            }
        )
        
        # Add perishable or nonperishable details
        if item_type == 'Perishable':
            expiry_date = request.POST.get('expirydate')
            refrigeration = request.POST.get('refrigeration', 'Required')
            
            Perishable.objects.update_or_create(
                itemid=item,
                defaults={
                    'refrigerationrequirement': refrigeration,
                    'hardexpirydate': expiry_date
                }
            )
        else:
            shelf_life = request.POST.get('shelflife', 365)
            
            Nonperishable.objects.update_or_create(
                itemid=item,
                defaults={
                    'shelfstableduration': shelf_life,
                    'stackinglimit': 10
                }
            )
            
        zone = Zone.objects.first()  # Get first available zone
        
        if zone:
            # Check if item already exists in this zone
            inventory, created = Inventoryassignment.objects.get_or_create(
                donationid=donation,
                zoneid=zone,
                itemid=item,
                defaults={
                    'assignmentid': donation.donationid,
                    'quantitystored': quantity,
                    'assigneddate': request.POST.get('donationdate'),
                }
            )
            if not created:
                inventory.quantitystored += quantity
                inventory.save()
            
            print(f"Added {quantity} x {item_name} to inventory in zone {zone.zonename}")
        
        
        # Create quality check log (pending)
        inspector = Inspector.objects.first()
        Qualitychecklog.objects.create(
            checkdate=request.POST.get('donationdate'),
            status='Pending',
            notes=f"Donation of {request.POST.get('quantity')} x {item_name}",
            donationid=donation,
            inspectorid=inspector
        )
        
        messages.success(request, f'Donation #{donation.donationid} created! Awaiting quality check.')
        return redirect('donor_dashboard')

# ============================================
# FORGOT PASSWORD
# ============================================

class ForgotPasswordView(View):
    template_name = 'base/forgot_password.html'
    
    def get(self, request):
        return render(request, self.template_name)
    
    def post(self, request):
        email = request.POST.get('email')
        try:
            user = User.objects.get(email=email)
            request.session['reset_user_id'] = user.id
            messages.success(request, 'Account found! Set your new password.')
            return redirect('reset_password')
        except User.DoesNotExist:
            messages.error(request, 'No account found with that email')
        return render(request, self.template_name)

class ResetPasswordView(View):
    template_name = 'base/reset_password.html'
    
    def get(self, request):
        if not request.session.get('reset_user_id'):
            return redirect('forgot_password')
        return render(request, self.template_name)
    
    def post(self, request):
        user_id = request.session.get('reset_user_id')
        if not user_id:
            return redirect('forgot_password')
        
        password = request.POST.get('password')
        confirm = request.POST.get('confirm_password')
        
        if not password or not confirm:
            messages.error(request, 'Please fill both fields')
            return render(request, self.template_name)
        if password != confirm:
            messages.error(request, 'Passwords do not match')
            return render(request, self.template_name)
        if len(password) < 6:
            messages.error(request, 'Password must be at least 6 characters')
            return render(request, self.template_name)
        
        user = User.objects.get(id=user_id)
        user.set_password(password)
        user.save()
        del request.session['reset_user_id']
        
        messages.success(request, 'Password reset successfully! Please login.')
        return redirect('login')
# ============================================
# DONATION CRUD (For donors)
# ============================================

class DonationUpdateView(View):
    template_name = 'base/donation_form.html'
    
    def get(self, request, pk):
        if not request.user.is_authenticated or request.user.user_type != 'donor':
            return redirect('login')
        
        donation = get_object_or_404(Donationevent, donationid=pk)
        return render(request, self.template_name, {'donation': donation})
    
    def post(self, request, pk):
        donation = get_object_or_404(Donationevent, donationid=pk)
        donation.donationdate = request.POST.get('donationdate')
        donation.totalweight = request.POST.get('totalweight')
        donation.save()
        messages.success(request, 'Donation updated successfully!')
        return redirect('donor_dashboard')

class DonationDeleteView(View):
    def post(self, request, pk):
        if not request.user.is_authenticated or request.user.user_type != 'donor':
            return redirect('login')
        
        donation = get_object_or_404(Donationevent, donationid=pk)
        donation.delete()
        messages.success(request, 'Donation deleted successfully!')
        return redirect('donor_dashboard')

# ============================================
# QUALITY CHECK (For volunteers)
# ============================================

class QualityCheckListView(View):
    template_name = 'base/quality_check_list.html'
    
    def get(self, request):
        if not request.user.is_authenticated or request.user.user_type != 'volunteer':
            return redirect('login')
        
        # Get pending quality checks
        pending_checks = Qualitychecklog.objects.filter(status='Pending').select_related('donationid', 'donationid__donorid')
        
        return render(request, self.template_name, {'pending_checks': pending_checks})

class QualityCheckUpdateView(View):
    template_name = 'base/quality_check_form.html'
    
    def get(self, request, pk):
        if not request.user.is_authenticated or request.user.user_type != 'volunteer':
            return redirect('login')
        
        quality_check = get_object_or_404(Qualitychecklog, lognumber=pk)
        return render(request, self.template_name, {'quality_check': quality_check})
    
    def post(self, request, pk):
        quality_check = get_object_or_404(Qualitychecklog, lognumber=pk)
        quality_check.status = request.POST.get('status')
        quality_check.notes = request.POST.get('notes')
        quality_check.save()
        
        messages.success(request, f'Quality check marked as {quality_check.status}!')
        return redirect('quality_check_list')

# ============================================
# DISTRIBUTION (For volunteers to assign packages to clients)
# ============================================

class DistributionCreateView(View):
    template_name = 'base/distribution_form.html'
    
    def get(self, request):
        if not request.user.is_authenticated or request.user.user_type != 'volunteer':
            return redirect('login')
        
        profile = VolunteerProfile.objects.get(user=request.user)
        volunteer = profile.existing_volunteer
        
        packages = Foodpackage.objects.all().order_by('-prepareddate')
        clients = Clientfamily.objects.all()
        
        return render(request, self.template_name, {
            'packages': packages,
            'clients': clients,
            'volunteer': volunteer
        })
    
    def post(self, request):
        if not request.user.is_authenticated or request.user.user_type != 'volunteer':
            return redirect('login')
        
        profile = VolunteerProfile.objects.get(user=request.user)
        volunteer = profile.existing_volunteer
        
        Distributionevent.objects.create(
            distributiondate=request.POST.get('distributiondate'),
            volid=volunteer,
            packageid_id=request.POST.get('package'),
            familyid_id=request.POST.get('client')
        )
        
        messages.success(request, 'Package assigned to client successfully!')
        return redirect('volunteer_dashboard')
    
    
class DistributionListView(View):
    template_name = 'base/distribution_list.html'
    
    def get(self, request):
        if not request.user.is_authenticated:
            return redirect('login')
        
        if request.user.user_type == 'volunteer':
            profile = VolunteerProfile.objects.get(user=request.user)
            volunteer = profile.existing_volunteer
            distributions = Distributionevent.objects.filter(volid=volunteer).order_by('-distributiondate')
        else:
            distributions = Distributionevent.objects.all().order_by('-distributiondate')
        
        # Add status to each distribution from DeliveryStatus table
        for dist in distributions:
            try:
                status_obj = DeliveryStatus.objects.filter(distribution=dist).first()
                dist.status = status_obj.status if status_obj else 'Pending'
            except:
                dist.status = 'Pending'
        
        return render(request, self.template_name, {'distributions': distributions})
    
    
class UpdateDeliveryStatusView(View):
    def post(self, request, pk):
        if not request.user.is_authenticated:
            return redirect('login')
        
        distribution = get_object_or_404(Distributionevent, distributionid=pk)
        new_status = request.POST.get('status')

        try:
            status_record, created = DeliveryStatus.objects.get_or_create(
                distribution=distribution,
                defaults={'status': new_status}
            )
            if not created:
                status_record.status = new_status
                status_record.save()
            messages.success(request, f'Delivery status updated to {new_status}')
        except:
            messages.warning(request, 'Status tracking not available')
        
        return redirect('distribution_list')

# ============================================
# ITEMS MANAGEMENT (For donors)
# ============================================

class ItemCreateView(View):
    template_name = 'base/item_form.html'
    
    def get(self, request):
        if not request.user.is_authenticated:
            return redirect('login')
        
        # Only donors can add items
        if request.user.user_type != 'donor':
            messages.error(request, 'Only donors can add items')
            return redirect('donor_dashboard')
        
        return render(request, self.template_name)
    
    def post(self, request):
        if not request.user.is_authenticated:
            return redirect('login')
        
        try:
            category = request.POST.get('category')
            
            # Create the item
            item = Items.objects.create(
                itemname=request.POST.get('itemname'),
                sku=request.POST.get('sku'),
                category=category
            )
            
            # Create perishable or nonperishable record
            if category == 'Perishable':
                Perishable.objects.create(
                    itemid=item,
                    refrigerationrequirement=request.POST.get('refrigerationrequirement', 'Required'),
                    hardexpirydate=request.POST.get('hardexpirydate')
                )
                messages.success(request, f'Perishable item "{item.itemname}" added successfully!')
            else:
                Nonperishable.objects.create(
                    itemid=item,
                    shelfstableduration=request.POST.get('shelfstableduration', 365),
                    stackinglimit=request.POST.get('stackinglimit', 10)
                )
                messages.success(request, f'Non-perishable item "{item.itemname}" added successfully!')
            
            return redirect('donor_dashboard')
            
        except Exception as e:
            messages.error(request, f'Error adding item: {str(e)}')
            return redirect('donor_dashboard')
        
# Add to views.py

class PackageCreateView(View):
    template_name = 'base/package_form.html'
    
    def get(self, request):
        if not request.user.is_authenticated or request.user.user_type != 'volunteer':
            return redirect('login')
        
        profile = VolunteerProfile.objects.get(user=request.user)
        volunteer = profile.existing_volunteer
        
        # Get items from volunteer's zones
        zones = Volunteerzone.objects.filter(volid=volunteer).values_list('zoneid', flat=True)
        items = Inventoryassignment.objects.filter(zoneid__in=zones, quantitystored__gt=0).select_related('itemid','zoneid')
        
        return render(request, self.template_name, {
            'volunteer': volunteer,
            'items': items,
            'zones': Zone.objects.filter(zoneid__in=zones)
        })
    
    def post(self, request):
        if not request.user.is_authenticated or request.user.user_type != 'volunteer':
            return redirect('login')
        
        profile = VolunteerProfile.objects.get(user=request.user)
        volunteer = profile.existing_volunteer
        
        # Create food package
        package = Foodpackage.objects.create(
            type=request.POST.get('package_type'),
            prepareddate=date.today(),
            zoneid_id=request.POST.get('zone')
        )
        
        # Add items to package
        item_ids = request.POST.getlist('items')
        quantities = request.POST.getlist('quantities')
        
        for i, item_id in enumerate(item_ids):
            if item_id and quantities[i]:
                Foodpackageitems.objects.create(
                    packageid=package,
                    itemid_id=item_id,
                    quantity=int(quantities[i])
                )
        
        messages.success(request, f'Food package "{package.type}" created successfully!')
        return redirect('package_list')
    
class PackageListView(View):
    template_name = 'base/package_list.html'
    
    def get(self, request):
        if not request.user.is_authenticated:
            return redirect('login')
        
        packages = Foodpackage.objects.all().order_by('-prepareddate')
        
        return render(request, self.template_name, {'packages': packages})
    
class ExpiringItemsReportView(View):
    template_name = 'base/expiring_items_report.html'
    
    def get(self, request):
        if not request.user.is_authenticated:
            return redirect('login')
        
        # Get days parameter from request (default 30 days)
        days = int(request.GET.get('days', 30))
        
        # Get all perishable items with their expiry dates
        perishable_items = Perishable.objects.select_related('itemid').all()
        
        report_data = []
        today = date.today()
        
        for item in perishable_items:
            expiry_date = item.hardexpirydate
            days_until_expiry = (expiry_date - today).days
            
            # Determine alert level
            if days_until_expiry <= 3:
                alert_level = 'Critical'
                alert_class = 'danger'
            elif days_until_expiry <= days:
                alert_level = 'Warning'
                alert_class = 'warning'
            else:
                alert_level = 'OK'
                alert_class = 'success'
            
            # Only include items expiring within the specified days
            if days_until_expiry <= days:
                report_data.append({
                    'item_name': item.itemid.itemname,
                    'sku': item.itemid.sku,
                    'category': item.itemid.category,
                    'expiry_date': expiry_date,
                    'days_until_expiry': days_until_expiry,
                    'alert_level': alert_level,
                    'alert_class': alert_class,
                    'refrigeration': item.refrigerationrequirement,
                })
        
        # Sort by days until expiry (closest first)
        report_data.sort(key=lambda x: x['days_until_expiry'])
        
        # Statistics
        critical_count = len([i for i in report_data if i['alert_level'] == 'Critical'])
        warning_count = len([i for i in report_data if i['alert_level'] == 'Warning'])
        ok_count = len([i for i in report_data if i['alert_level'] == 'OK'])
        
        context = {
            'report_data': report_data,
            'days': days,
            'critical_count': critical_count,
            'warning_count': warning_count,
            'ok_count': ok_count,
            'total_count': len(report_data),
            'today': today,
        }
        
        return render(request, self.template_name, context)
    
class DonorToFamilyReportView(View):
    template_name = 'base/donor_family_report.html'
    
    def get(self, request):
        if not request.user.is_authenticated:
            return redirect('login')
        
        # Get date range filters
        start_date = request.GET.get('start_date')
        end_date = request.GET.get('end_date')
        
        # Base query: get all distributions with their packages and donations
        distributions = Distributionevent.objects.select_related(
            'familyid', 'packageid', 'volid'
        ).all().order_by('-distributiondate')
        
        # Apply date filters
        if start_date:
            distributions = distributions.filter(distributiondate__gte=start_date)
        if end_date:
            distributions = distributions.filter(distributiondate__lte=end_date)
        
        report_data = []
        
        for dist in distributions:
            # Find which donor provided the items in this package
            donors_involved = set()
            items_list = []
            
            # Get items in this package
            package_items = Foodpackageitems.objects.filter(packageid=dist.packageid).select_related('itemid')
            
            for pkg_item in package_items:
                # Find which donation this item came from
                inventory = Inventoryassignment.objects.filter(
                    itemid=pkg_item.itemid
                ).select_related('donationid', 'donationid__donorid').first()
                
                if inventory and inventory.donationid and inventory.donationid.donorid:
                    donor = inventory.donationid.donorid
                    donors_involved.add(donor.donorname)
                    
                    items_list.append({
                        'item_name': pkg_item.itemid.itemname,
                        'quantity': pkg_item.quantity,
                        'donor': donor.donorname,
                    })
            
            report_data.append({
                'distribution_date': dist.distributiondate,
                'family_name': dist.familyid.familyname,
                'family_address': dist.familyid.address,
                'family_phone': dist.familyid.phone,
                'package_type': dist.packageid.type if dist.packageid else 'Unknown',
                'volunteer_name': f"{dist.volid.firstname} {dist.volid.lastname}" if dist.volid else 'Unknown',
                'donors': ', '.join(donors_involved) if donors_involved else 'Unknown',
                'items': items_list,
                'total_items': len(items_list),
            })
        
        # Statistics
        total_families = len(set([d['family_name'] for d in report_data]))
        total_donors = len(set([d for dist in report_data for d in dist['donors'].split(', ') if d != 'Unknown']))
        
        context = {
            'report_data': report_data,
            'start_date': start_date,
            'end_date': end_date,
            'total_distributions': len(report_data),
            'total_families': total_families,
            'total_donors': total_donors,
        }
        
        return render(request, self.template_name, context)