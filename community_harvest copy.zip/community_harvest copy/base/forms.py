from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import (
    User, Volunteer, Donor, Clientfamily, Contactperson,
    VolunteerProfile, DonorProfile, ClientProfile
)

# ============================================
# VOLUNTEER REGISTRATION FORM
# ============================================

class VolunteerRegistrationForm(UserCreationForm):
    firstname = forms.CharField(max_length=255, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'First Name'}))
    lastname = forms.CharField(max_length=255, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Last Name'}))
    phone = forms.CharField(max_length=20, required=False, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Phone'}))
    email = forms.EmailField(widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Email'}))
    
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2', 'firstname', 'lastname', 'phone']
    
    def clean_email(self):
        email = self.cleaned_data.get('email')
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError("Email already registered")
        if Volunteer.objects.filter(email=email).exists():
            raise forms.ValidationError("Email already registered as volunteer")
        return email
    
    def clean_username(self):
        username = self.cleaned_data.get('username')
        if User.objects.filter(username=username).exists():
            raise forms.ValidationError("Username already taken")
        return username
    
    def save(self, commit=True):
        user = super().save(commit=False)
        user.user_type = 'volunteer'
        user.first_name = self.cleaned_data['firstname']
        user.last_name = self.cleaned_data['lastname']
        user.email = self.cleaned_data['email']
        user.phone = self.cleaned_data['phone']
        
        if commit:
            user.save()
            # Create volunteer record
            volunteer = Volunteer.objects.create(
                firstname=self.cleaned_data['firstname'],
                lastname=self.cleaned_data['lastname'],
                phone=self.cleaned_data['phone'],
                email=self.cleaned_data['email'],
                role='Volunteer'  # Default role, can be updated later
            )
            # Create profile link
            VolunteerProfile.objects.create(user=user, existing_volunteer=volunteer)
        
        return user

# ============================================
# DONOR REGISTRATION FORM
# ============================================

class DonorRegistrationForm(UserCreationForm):
    donorname = forms.CharField(max_length=255, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Organization/Individual Name'}))
    donortype = forms.ChoiceField(choices=[('Organization', 'Organization'), ('Individual', 'Individual')], 
                                   widget=forms.Select(attrs={'class': 'form-control'}))
    
    class Meta:
        model = User
        fields = ['username', 'password1', 'password2', 'donorname', 'donortype']
    
    def clean_username(self):
        username = self.cleaned_data.get('username')
        if User.objects.filter(username=username).exists():
            raise forms.ValidationError("Username already taken")
        return username
    
    def save(self, commit=True):
        user = super().save(commit=False)
        user.user_type = 'donor'
        user.first_name = self.cleaned_data['donorname']
        
        if commit:
            user.save()
            # Create donor record
            donor = Donor.objects.create(
                donorname=self.cleaned_data['donorname'],
                donortype=self.cleaned_data['donortype']
            )
            # Create profile link
            DonorProfile.objects.create(user=user, existing_donor=donor)
        
        return user

# ============================================
# CLIENT REGISTRATION FORM
# ============================================

class ClientRegistrationForm(UserCreationForm):
    familyname = forms.CharField(max_length=255, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Family Name'}))
    address = forms.CharField(widget=forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Address', 'rows': 2}))
    phone = forms.CharField(max_length=20, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Phone'}))
    familysize = forms.IntegerField(widget=forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Family Size'}))
    
    class Meta:
        model = User
        fields = ['username', 'password1', 'password2', 'familyname', 'address', 'phone', 'familysize']
    
    def clean_username(self):
        username = self.cleaned_data.get('username')
        if User.objects.filter(username=username).exists():
            raise forms.ValidationError("Username already taken")
        return username
    
    def save(self, commit=True):
        user = super().save(commit=False)
        user.user_type = 'client'
        user.first_name = self.cleaned_data['familyname']
        
        if commit:
            user.save()
            # Create client record
            client = Clientfamily.objects.create(
                familyname=self.cleaned_data['familyname'],
                address=self.cleaned_data['address'],
                phone=self.cleaned_data['phone'],
                familysize=self.cleaned_data['familysize']
            )
            # Create profile link
            ClientProfile.objects.create(user=user, existing_client=client)
        
        return user

# ============================================
# CONTACT PERSON FORM (For donors after signup)
# ============================================

class ContactPersonForm(forms.ModelForm):
    class Meta:
        model = Contactperson
        fields = ['name', 'phone', 'email']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Contact Name'}),
            'phone': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Phone Number'}),
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Email Address'}),
        }