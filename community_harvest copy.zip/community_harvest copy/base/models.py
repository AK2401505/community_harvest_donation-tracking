from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    USER_TYPE_CHOICES = [
        ('volunteer', 'Volunteer'),
        ('donor', 'Donor'),
        ('client', 'Client'),
    ]
    
    user_type = models.CharField(max_length=20, choices=USER_TYPE_CHOICES)
    phone = models.CharField(max_length=20, blank=True, null=True)
    
    class Meta:
        db_table = 'auth_user'
    
    def __str__(self):
        return self.username


# Profile models that link to your existing tables
class VolunteerProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='volunteer_profile')
    # Link to your existing volunteer table
    existing_volunteer = models.OneToOneField('Volunteer', on_delete=models.CASCADE, null=True, blank=True)
    
    class Meta:
        db_table = 'volunteer_profiles'


class DonorProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='donor_profile')
    existing_donor = models.OneToOneField('Donor', on_delete=models.CASCADE, null=True, blank=True)
    
    class Meta:
        db_table = 'donor_profiles'


class ClientProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='client_profile')
    existing_client = models.OneToOneField('Clientfamily', on_delete=models.CASCADE, null=True, blank=True)
    
    class Meta:
        db_table = 'client_profiles'



class Clientfamily(models.Model):
    familyid = models.AutoField(primary_key=True)
    familyname = models.CharField(max_length=255)
    address = models.CharField(max_length=255)
    phone = models.CharField(max_length=20, blank=True, null=True)
    familysize = models.IntegerField()

    class Meta:
        db_table = 'clientfamily'


class Contactperson(models.Model):
    contactid = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)
    phone = models.CharField(max_length=20, blank=True, null=True)
    email = models.CharField(max_length=255, blank=True, null=True)
    donorid = models.ForeignKey('Donor', models.DO_NOTHING, db_column='donorid')

    class Meta:
        db_table = 'contactperson'


class Distributionevent(models.Model):
    distributionid = models.AutoField(primary_key=True)
    distributiondate = models.DateField()
    volid = models.ForeignKey('Volunteer', models.DO_NOTHING, db_column='volid', blank=True, null=True)
    packageid = models.ForeignKey('Foodpackage', models.DO_NOTHING, db_column='packageid', blank=True, null=True)
    familyid = models.ForeignKey(Clientfamily, models.DO_NOTHING, db_column='familyid')

    class Meta:
        db_table = 'distributionevent'


class Donationevent(models.Model):
    donationid = models.AutoField(primary_key=True)
    donationdate = models.DateField()
    totalweight = models.IntegerField()
    donorid = models.ForeignKey('Donor', models.DO_NOTHING, db_column='donorid')

    class Meta:
        db_table = 'donationevent'


class Donationeventaudit(models.Model):
    auditid = models.AutoField(primary_key=True)
    donationid = models.ForeignKey(Donationevent, models.DO_NOTHING, db_column='donationid', blank=True, null=True)
    oldtotalweight = models.IntegerField(blank=True, null=True)
    newtotalweight = models.IntegerField(blank=True, null=True)
    changedate = models.DateTimeField(blank=True, null=True)
    actiontype = models.CharField(max_length=10, blank=True, null=True)
    changedby = models.CharField(max_length=50, blank=True, null=True)

    class Meta:
        db_table = 'donationeventaudit'


class Donationlineitem(models.Model):
    quantity = models.IntegerField()
    batchexpirydate = models.DateField(blank=True, null=True)
    donationid = models.ForeignKey(Donationevent, models.DO_NOTHING, db_column='donationid')
    inventoryid = models.ForeignKey('Inventoryassignment', models.DO_NOTHING, db_column='inventoryid')

    class Meta:
        db_table = 'donationlineitem'


class Donationwarehouse(models.Model):
    donationid = models.ForeignKey(Donationevent, models.DO_NOTHING, db_column='donationid')
    warehouseid = models.ForeignKey('Warehouse', models.DO_NOTHING, db_column='warehouseid')

    class Meta:
        db_table = 'donationwarehouse'


class Donor(models.Model):
    donorid = models.AutoField(primary_key=True)
    donorname = models.CharField(max_length=255)
    donortype = models.CharField(max_length=255)

    class Meta:
        db_table = 'donor'


class Evaluationhistory(models.Model):
    itemvalue = models.IntegerField()
    timeofdonation = models.IntegerField()
    itemid = models.ForeignKey('Items', models.DO_NOTHING, db_column='itemid')

    class Meta:
        db_table = 'evaluationhistory'


class Foodpackage(models.Model):
    packageid = models.AutoField(primary_key=True)
    type = models.CharField(max_length=255)
    prepareddate = models.DateField()
    zoneid = models.ForeignKey('Zone', models.DO_NOTHING, db_column='zoneid', blank=True, null=True)

    class Meta:
        db_table = 'foodpackage'


class Foodpackageitems(models.Model):
    packageid = models.ForeignKey(Foodpackage, models.DO_NOTHING, db_column='packageid')
    itemid = models.ForeignKey('Items', models.DO_NOTHING, db_column='itemid')
    quantity = models.IntegerField()

    class Meta:
        db_table = 'foodpackageitems'


class Inspector(models.Model):
    inspectorid = models.AutoField(primary_key=True)
    inspectorsname = models.CharField(max_length=255)

    class Meta:
        db_table = 'inspector'


class Inventoryassignment(models.Model):
    assignmentid = models.IntegerField(blank=True, null=True)
    quantitystored = models.IntegerField()
    assigneddate = models.DateField()
    donationid = models.ForeignKey(Donationevent, models.DO_NOTHING, db_column='donationid')
    zoneid = models.ForeignKey('Zone', models.DO_NOTHING, db_column='zoneid')
    itemid = models.ForeignKey('Items', models.DO_NOTHING, db_column='itemid')

    class Meta:
        db_table = 'inventoryassignment'


class Items(models.Model):
    itemid = models.AutoField(primary_key=True)
    itemname = models.CharField(max_length=255)
    sku = models.IntegerField(unique=True)
    category = models.CharField(max_length=255)

    class Meta:
        db_table = 'items'


class Nonperishable(models.Model):
    itemid = models.OneToOneField(Items, models.DO_NOTHING, db_column='itemid', primary_key=True)
    shelfstableduration = models.IntegerField()
    stackinglimit = models.IntegerField()

    class Meta:
        db_table = 'nonperishable'


class Perishable(models.Model):
    itemid = models.OneToOneField(Items, models.DO_NOTHING, db_column='itemid', primary_key=True)
    refrigerationrequirement = models.CharField(max_length=50)
    hardexpirydate = models.DateField()

    class Meta:
        db_table = 'perishable'


class Qualitychecklog(models.Model):
    lognumber = models.AutoField(primary_key=True)
    checkdate = models.DateField()
    status = models.CharField(max_length=255)
    notes = models.TextField(blank=True, null=True)
    donationid = models.ForeignKey(Donationevent, models.DO_NOTHING, db_column='donationid')
    inspectorid = models.ForeignKey(Inspector, models.DO_NOTHING, db_column='inspectorid')

    class Meta:
        db_table = 'qualitychecklog'


class Volunteer(models.Model):
    volid = models.AutoField(primary_key=True)
    firstname = models.CharField(max_length=255)
    lastname = models.CharField(max_length=255)
    phone = models.CharField(max_length=20, blank=True, null=True)
    email = models.CharField(unique=True, max_length=255, blank=True, null=True)
    role = models.CharField(max_length=255)

    class Meta:
        db_table = 'volunteer'


class Volunteerzone(models.Model):
    volid = models.ForeignKey(Volunteer, models.DO_NOTHING, db_column='volid')
    zoneid = models.ForeignKey('Zone', models.DO_NOTHING, db_column='zoneid')

    class Meta:
        db_table = 'volunteerzone'


class Warehouse(models.Model):
    warehouseid = models.AutoField(primary_key=True)
    street = models.CharField(max_length=255)
    docknumber = models.IntegerField(blank=True, null=True)
    city = models.CharField(max_length=255)
    zipcode = models.IntegerField(blank=True, null=True)

    class Meta:
        db_table = 'warehouse'


class Zone(models.Model):
    zoneid = models.AutoField(primary_key=True)
    zonename = models.CharField(max_length=255)
    temperaturetype = models.CharField(max_length=255)
    warehouseid = models.ForeignKey(Warehouse, models.DO_NOTHING, db_column='warehouseid')

    class Meta:
        db_table = 'zone'
        
# ============================================
# DELIVERY STATUS TABLE (NEW - For tracking package delivery)
# ============================================

class DeliveryStatus(models.Model):
    STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('In Transit', 'In Transit'),
        ('Delivered', 'Delivered'),
        ('Cancelled', 'Cancelled'),
    ]
    
    distribution = models.OneToOneField(
        'Distributionevent', 
        on_delete=models.CASCADE, 
        primary_key=True,
        db_column='distributionid'
    )
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Pending')
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        managed = True
        db_table = 'delivery_status'
    
    def __str__(self):
        return f"Distribution {self.distribution.distributionid} - {self.status}"
