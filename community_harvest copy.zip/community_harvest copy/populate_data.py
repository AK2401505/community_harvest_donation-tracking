#!/usr/bin/env python
"""
DATA POPULATION SCRIPT FOR COMMUNITY HARVEST
Run this script to populate 20 records per table
"""

import os
import django
import random
from datetime import date, timedelta

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'community_harvest.settings')
django.setup()

from base.models import (
    Donor, Contactperson, Warehouse, Zone, Items, Perishable, Nonperishable,
    Donationevent, Inspector, Qualitychecklog, Inventoryassignment, Donationlineitem,
    Donationwarehouse, Volunteer, Volunteerzone, Foodpackage, Foodpackageitems,
    Clientfamily, Distributionevent, Evaluationhistory
)

def clear_existing_data():
    """Clear existing data to avoid duplicates"""
    print("\n" + "=" * 60)
    print("CLEARING EXISTING DATA")
    print("=" * 60)
    
    # Delete in correct order (children first)
    Distributionevent.objects.all().delete()
    Foodpackageitems.objects.all().delete()
    Foodpackage.objects.all().delete()
    Volunteerzone.objects.all().delete()
    Volunteer.objects.all().delete()
    Donationwarehouse.objects.all().delete()
    Donationlineitem.objects.all().delete()
    Inventoryassignment.objects.all().delete()
    Qualitychecklog.objects.all().delete()
    Donationevent.objects.all().delete()
    Contactperson.objects.all().delete()
    Donor.objects.all().delete()
    Zone.objects.all().delete()
    Warehouse.objects.all().delete()
    Perishable.objects.all().delete()
    Nonperishable.objects.all().delete()
    Items.objects.all().delete()
    Clientfamily.objects.all().delete()
    Distributionevent.objects.all().delete()
    Evaluationhistory.objects.all().delete()
    Inspector.objects.all().delete()
    
    print("✓ All existing data cleared")

def populate_data():
    """Main function to populate 20 records per table"""
    
    print("=" * 60)
    print("POPULATING COMMUNITY HARVEST DATABASE")
    print("20 RECORDS PER TABLE")
    print("=" * 60)

    # ============================================
    # 1. INSPECTOR (ONLY 5 records - FIXED)
    # ============================================
    print("\n1. Creating Inspectors (5 only)...")
    inspector_names = [
        'Dr. Ahmed El-Sayed',
        'Dr. Mona Abdelrahman', 
        'Dr. Khaled Hassan',
        'Dr. Fatma Zohra',
        'Dr. Youssef Amin'
    ]
    inspectors = []
    for name in inspector_names:
        inspector = Inspector.objects.create(inspectorsname=name)
        inspectors.append(inspector)
        print(f"  ✓ Created: {inspector.inspectorsname}")
    print(f"  Total: {len(inspectors)} inspectors")

    # ============================================
    # 2. DONOR (20 records)
    # ============================================
    print("\n2. Creating Donors (20)...")
    donor_names = [
        'Cairo Food Bank', 'Ahmed Mansour', 'Alexandria Farmers Market', 'Mona El-Sayed',
        'Egyptian Food Bank', 'Karim Hassan', 'Nile Delta Farms', 'Samira Ahmed',
        'Spinneys Egypt', 'Youssef Ibrahim', 'Giza Bakery', 'Nourhan Khalid',
        'Port Said Fisheries', 'Omar Farouk', 'Suez Canal Foundation', 'Laila Mahmoud',
        'Mansoura Food Bank', 'Samir George', 'Luxor Charity', 'Dina Sherif'
    ]
    donors = []
    for i, name in enumerate(donor_names):
        donor_type = 'Organization' if i % 2 == 0 else 'Individual'
        donor = Donor.objects.create(donorname=name, donortype=donor_type)
        donors.append(donor)
        print(f"  ✓ Created: {donor.donorname} ({donor.donortype})")

    # ============================================
    # 3. CONTACT PERSON (3 per org, 2 per ind)
    # ============================================
    print("\n3. Creating Contact Persons...")
    contact_count = 0
    for donor in donors:
        num_contacts = 3 if donor.donortype == 'Organization' else 2
        for j in range(num_contacts):
            Contactperson.objects.create(
                name=f"Contact Person {j+1} for {donor.donorname}",
                phone=f"010{random.randint(10000000, 99999999)}",
                email=f"contact_{donor.donorid}_{j+1}@example.com",
                donorid=donor
            )
            contact_count += 1
    print(f"  ✓ Created {contact_count} contact persons")

    # ============================================
    # 4. WAREHOUSE (20 records)
    # ============================================
    print("\n4. Creating Warehouses (20)...")
    cities = ['Cairo', 'Alexandria', 'Giza', 'Port Said', 'Mansoura', 'Tanta', 'Aswan', 'Luxor', 'Ismailia', 'Suez']
    streets = ['Industrial Zone', 'Commercial Area', 'Business Park', 'Trade Center', 'Food District']
    warehouses = []
    for i in range(20):
        warehouse = Warehouse.objects.create(
            street=f"{random.randint(1, 100)} {streets[i % len(streets)]}",
            docknumber=random.randint(1, 5),
            city=cities[i % len(cities)],
            zipcode=random.randint(10000, 99999)
        )
        warehouses.append(warehouse)
        print(f"  ✓ Created: {warehouse.city} - {warehouse.street}")

    # ============================================
    # 5. ZONE (20 records)
    # ============================================
    print("\n5. Creating Zones (20)...")
    zone_names = ['Cold Storage', 'Dry Storage', 'Chilled Section', 'Pantry Area', 'Frozen Section']
    temp_types = ['Refrigerated', 'Shelf']
    zones = []
    for i in range(20):
        zone = Zone.objects.create(
            zonename=zone_names[i % len(zone_names)],
            temperaturetype=random.choice(temp_types),
            warehouseid=warehouses[i % len(warehouses)]
        )
        zones.append(zone)
        print(f"  ✓ Created: {zone.zonename} ({zone.temperaturetype})")

    # ============================================
    # 6. ITEMS (20 records)
    # ============================================
    print("\n6. Creating Items (20)...")
    items_data = [
        ('Fresh Milk', 1001, 'Perishable'), ('Canned Beans', 1002, 'NonPerishable'),
        ('Chicken Breast', 1003, 'Perishable'), ('White Rice', 1004, 'NonPerishable'),
        ('Eggs', 1005, 'Perishable'), ('Pasta', 1006, 'NonPerishable'),
        ('Tomato Sauce', 1007, 'NonPerishable'), ('Fresh Bread', 1008, 'Perishable'),
        ('Frozen Vegetables', 1009, 'Perishable'), ('Cooking Oil', 1010, 'NonPerishable'),
        ('Yogurt', 1011, 'Perishable'), ('Canned Tuna', 1012, 'NonPerishable'),
        ('Fresh Beef', 1013, 'Perishable'), ('Lentils', 1014, 'NonPerishable'),
        ('Cheese', 1015, 'Perishable'), ('Cereal', 1016, 'NonPerishable'),
        ('Orange Juice', 1017, 'Perishable'), ('Flour', 1018, 'NonPerishable'),
        ('Butter', 1019, 'Perishable'), ('Sugar', 1020, 'NonPerishable')
    ]
    items = []
    for item_name, sku, category in items_data:
        item = Items.objects.create(itemname=item_name, sku=sku, category=category)
        items.append(item)
        print(f"  ✓ Created: {item.itemname}")

    # ============================================
    # 7. PERISHABLE (for perishable items only)
    # ============================================
    print("\n7. Creating Perishable records...")
    perishable_count = 0
    for item in items:
        if item.category == 'Perishable':
            Perishable.objects.create(
                itemid=item,
                refrigerationrequirement='Required',
                hardexpirydate=date(2026, random.randint(6, 12), random.randint(1, 28))
            )
            perishable_count += 1
            print(f"  ✓ Created perishable: {item.itemname}")
    print(f"  Total perishable: {perishable_count}")

    # ============================================
    # 8. NONPERISHABLE (for non-perishable items only)
    # ============================================
    print("\n8. Creating NonPerishable records...")
    nonperishable_count = 0
    for item in items:
        if item.category == 'NonPerishable':
            Nonperishable.objects.create(
                itemid=item,
                shelfstableduration=random.randint(180, 730),
                stackinglimit=random.randint(5, 20)
            )
            nonperishable_count += 1
            print(f"  ✓ Created nonperishable: {item.itemname}")
    print(f"  Total nonperishable: {nonperishable_count}")

    # ============================================
    # 9. DONATION EVENT (20 records)
    # ============================================
    print("\n9. Creating Donation Events (20)...")
    donation_events = []
    for i in range(20):
        donation = Donationevent.objects.create(
            donationdate=date(2026, random.randint(6, 9), random.randint(1, 28)),
            totalweight=random.randint(50, 1000),
            donorid=random.choice(donors)
        )
        donation_events.append(donation)
        print(f"  ✓ Created donation #{donation.donationid}")

    # ============================================
    # 10. QUALITY CHECK LOG (20 records)
    # ============================================
    print("\n10. Creating Quality Check Logs (20)...")
    statuses = ['Pass', 'Fail', 'Pending', 'Review']
    for i, donation in enumerate(donation_events):
        Qualitychecklog.objects.create(
            checkdate=donation.donationdate,
            status=random.choice(statuses),
            notes=f"Quality check notes for donation #{donation.donationid}",
            donationid=donation,
            inspectorid=random.choice(inspectors)
        )
        print(f"  ✓ Created quality check for donation #{donation.donationid}")

    # ============================================
    # 11. INVENTORY ASSIGNMENT (20 records)
    # ============================================
    print("\n11. Creating Inventory Assignments (20)...")
    inventory_assignments = []
    for i in range(20):
        assignment = Inventoryassignment.objects.create(
            assignmentid=100 + i,
            quantitystored=random.randint(50, 500),
            assigneddate=date(2026, random.randint(6, 9), random.randint(1, 28)),
            donationid=random.choice(donation_events),
            zoneid=random.choice(zones),
            itemid=random.choice(items)
        )
        inventory_assignments.append(assignment)
        print(f"  ✓ Created inventory assignment #{assignment.assignmentid}")

    # ============================================
    # 12. DONATION LINE ITEM (20 records)
    # ============================================
    print("\n12. Creating Donation Line Items (20)...")
    for i, assignment in enumerate(inventory_assignments):
        Donationlineitem.objects.create(
            quantity=random.randint(10, 200),
            batchexpirydate=date(2026, random.randint(7, 12), random.randint(1, 28)),
            donationid=random.choice(donation_events),
            inventoryid=assignment
        )
        print(f"  ✓ Created line item for inventory #{assignment.assignmentid}")

    # ============================================
    # 13. DONATION WAREHOUSE (20 records)
    # ============================================
    print("\n13. Creating Donation Warehouse links (20)...")
    for i, donation in enumerate(donation_events):
        Donationwarehouse.objects.create(
            donationid=donation,
            warehouseid=random.choice(warehouses)
        )
        print(f"  ✓ Linked donation #{donation.donationid} to warehouse")

    # ============================================
    # 14. VOLUNTEER (20 records)
    # ============================================
    print("\n14. Creating Volunteers (20)...")
    first_names = ['Ahmed', 'Sara', 'Mohamed', 'Nour', 'Omar', 'Laila', 'Youssef', 'Mariam', 'Khaled', 'Heba']
    last_names = ['Ali', 'Hassan', 'Ibrahim', 'Khaled', 'Said', 'Mostafa', 'George', 'Adel', 'Nabil', 'Tarek']
    volunteers = []
    for i in range(20):
        role = 'Squad Leader' if random.choice([True, False, False, False]) else 'Volunteer'
        volunteer = Volunteer.objects.create(
            firstname=random.choice(first_names),
            lastname=random.choice(last_names),
            phone=f"010{random.randint(10000000, 99999999)}",
            email=f"volunteer{i+1}@communityharvest.org",
            role=role
        )
        volunteers.append(volunteer)
        print(f"  ✓ Created: {volunteer.firstname} {volunteer.lastname} ({volunteer.role})")

    # ============================================
    # 15. VOLUNTEER ZONE (20 records)
    # ============================================
    print("\n15. Creating Volunteer Zone assignments (20)...")
    for i, volunteer in enumerate(volunteers):
        Volunteerzone.objects.create(
            volid=volunteer,
            zoneid=random.choice(zones)
        )
        print(f"  ✓ Assigned {volunteer.firstname} to zone")

    # ============================================
    # 16. FOOD PACKAGE (20 records)
    # ============================================
    print("\n16. Creating Food Packages (20)...")
    package_types = ['Family Meal Box', 'Emergency Food Kit', 'Dairy Pack', 'Protein Box', 'Vegetarian Box']
    food_packages = []
    for i in range(20):
        package = Foodpackage.objects.create(
            type=random.choice(package_types),
            prepareddate=date(2026, random.randint(6, 9), random.randint(1, 28)),
            zoneid=random.choice(zones)
        )
        food_packages.append(package)
        print(f"  ✓ Created: {package.type}")

    # ============================================
    # 17. FOOD PACKAGE ITEMS (20 records)
    # ============================================
    print("\n17. Creating Food Package Items (20)...")
    for i, package in enumerate(food_packages):
        Foodpackageitems.objects.create(
            packageid=package,
            itemid=random.choice(items),
            quantity=random.randint(1, 5)
        )
        print(f"  ✓ Added items to package #{package.packageid}")

    # ============================================
    # 18. CLIENT FAMILY (20 records)
    # ============================================
    print("\n18. Creating Client Families (20)...")
    family_names = [
        'Ahmed Family', 'Mona Family', 'Youssef Family', 'Fatma Family', 'Omar Family',
        'Nour Family', 'Laila Family', 'Hany Family', 'Dina Family', 'Samir Family',
        'Khaled Family', 'Amira Family', 'Mostafa Family', 'Reem Family', 'Tarek Family',
        'Soha Family', 'Adel Family', 'Maha Family', 'Sherif Family', 'Eman Family'
    ]
    clients = []
    for i, name in enumerate(family_names):
        client = Clientfamily.objects.create(
            familyname=name,
            address=f"{random.randint(1, 200)} {['Tahrir', 'Nile', 'October', 'Pyramid'][i % 4]} Street",
            phone=f"010{random.randint(10000000, 99999999)}",
            familysize=random.randint(2, 8)
        )
        clients.append(client)
        print(f"  ✓ Created: {client.familyname}")

    # ============================================
    # 19. DISTRIBUTION EVENT (20 records)
    # ============================================
    print("\n19. Creating Distribution Events (20)...")
    for i in range(20):
        Distributionevent.objects.create(
            distributiondate=date(2026, random.randint(6, 10), random.randint(1, 28)),
            volid=random.choice(volunteers),
            packageid=random.choice(food_packages),
            familyid=random.choice(clients)
        )
        print(f"  ✓ Created distribution event #{i+1}")

    # ============================================
    # 20. EVALUATION HISTORY (20 records)
    # ============================================
    print("\n20. Creating Evaluation History (20)...")
    for i, item in enumerate(items[:20]):
        Evaluationhistory.objects.create(
            itemvalue=random.randint(1, 5),
            timeofdonation=random.randint(6, 96),
            itemid=item
        )
        print(f"  ✓ Created evaluation for: {item.itemname}")

    # ============================================
    # SUMMARY
    # ============================================
    print("\n" + "=" * 60)
    print("✅ DATA POPULATION COMPLETE!")
    print("=" * 60)
    print(f"\n📊 SUMMARY:")
    print(f"   • Inspectors: {Inspector.objects.count()} (5 total)")
    print(f"   • Donors: {Donor.objects.count()}")
    print(f"   • Contact Persons: {Contactperson.objects.count()}")
    print(f"   • Warehouses: {Warehouse.objects.count()}")
    print(f"   • Zones: {Zone.objects.count()}")
    print(f"   • Items: {Items.objects.count()}")
    print(f"   • Perishable: {Perishable.objects.count()}")
    print(f"   • Nonperishable: {Nonperishable.objects.count()}")
    print(f"   • Donation Events: {Donationevent.objects.count()}")
    print(f"   • Quality Checks: {Qualitychecklog.objects.count()}")
    print(f"   • Inventory Assignments: {Inventoryassignment.objects.count()}")
    print(f"   • Donation Line Items: {Donationlineitem.objects.count()}")
    print(f"   • Donation Warehouse: {Donationwarehouse.objects.count()}")
    print(f"   • Volunteers: {Volunteer.objects.count()}")
    print(f"   • Volunteer Zones: {Volunteerzone.objects.count()}")
    print(f"   • Food Packages: {Foodpackage.objects.count()}")
    print(f"   • Food Package Items: {Foodpackageitems.objects.count()}")
    print(f"   • Client Families: {Clientfamily.objects.count()}")
    print(f"   • Distribution Events: {Distributionevent.objects.count()}")
    print(f"   • Evaluation History: {Evaluationhistory.objects.count()}")
    print("=" * 60)

if __name__ == "__main__":
    # Ask user if they want to clear existing data
    response = input("\n⚠️  This will DELETE all existing data and create NEW 20 records per table. Continue? (yes/no): ")
    if response.lower() == 'yes':
        clear_existing_data()
        populate_data()
    else:
        print("Operation cancelled.")